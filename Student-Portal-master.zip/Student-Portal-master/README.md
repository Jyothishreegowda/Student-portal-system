# Student Portal
A web portal for students to access all their course information.
  
Backend is designed using PHP and MySQL.


